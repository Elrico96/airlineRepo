package com.example.kulula.kulula;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KululaApplication {

	public static void main(String[] args) {
		SpringApplication.run(KululaApplication.class, args);
	}
}
